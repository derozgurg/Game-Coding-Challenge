export const AssetsPack = {
    Background: {
        BusinessHolder: 'assets/bar_back.png',
        TimeBar: 'assets/bar.png'
    },
    button:{
        upgradeButton:'assets/buy_upgrade.png'
    }
}

export const StageSize = {
    width:720,
    height:640
}

export const Businesses = [
    {
        name: 'Grocer',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    },
    {
        name: 'Store',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    },
    {
        name: 'Real Estate',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    }, {
        name: 'Courier company',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    },
    {
        name: 'Game Studio',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    },
    {
        name: 'Electric Car',
        initalDuration: 10,
        icon: '',
        cost: 1000,
    },
]