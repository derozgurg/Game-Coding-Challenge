import * as PIXI from "pixi.js"
import App from "../app";

class DisplayObject extends PIXI.Sprite {
    constructor(texture?:PIXI.Texture){
        super(texture);              
        App.getApp().then(app=>{
            app.addFrame(this.onFrame.bind(this));
        });
    }
     onFrame(){}
}

export default DisplayObject