import BusinessHolder from "./bussiness/BusinessHolder";
import * as PIXI from "pixi.js"
import { Businesses, StageSize } from '../config';
import DisplayObject from "../core/GameDisplayObject";
import App from '../app';

class Game {
    stage: PIXI.Container;
    app: App;
    businessesHolder: PIXI.Container;

    constructor(app: App) {
        this.stage = app.pixiApp.stage;
        this.app = app;
    }

    start() {
        let text = new PIXI.Text('$0', { fontSize: 30, fill: 0x000000, align: 'center' });
        
        text.x = (StageSize.width - text.width) / 2;
        text.y = 10;
        this.stage.addChild(text);
        this.setupBusinessesHolder();
    }

    setupBusinessesHolder() {
        const marginX = 60;
        const marginY = 35;
        const businessesHolder = new PIXI.Container();
        for (let i = 0; i < Businesses.length; i++) {
            const businessData = Businesses[i];
            const businessHolder = new BusinessHolder(businessData);
            businessHolder.y = i * (businessHolder.height + marginY);

            if (i > 2) {
                businessHolder.y = (i - 3) * (businessHolder.height + marginY);
                businessHolder.x = marginX + businessHolder.width;
            }

            businessesHolder.addChild(businessHolder)
        }

        businessesHolder.x = (720 - businessesHolder.width) / 2;
        businessesHolder.y = 150;
        this.stage.addChild(businessesHolder);
    }
}

export default Game;