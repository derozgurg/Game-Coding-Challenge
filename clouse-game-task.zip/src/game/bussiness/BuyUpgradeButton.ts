import * as PIXI from "pixi.js"
import { AssetsPack } from '../../config';

class BuyUpgradeButton extends PIXI.Sprite {


    constructor(process: number = 0) {
        super(PIXI.utils.TextureCache[AssetsPack.button.upgradeButton]);
        this.setup();
    }

    setup() {
        let text = new PIXI.Text('BUY $0', { fontSize: 15, fill: 0x000000});
        text.x = 5;
        text.y = 5;
        this.addChild(text);
    }
}

export default BuyUpgradeButton;

