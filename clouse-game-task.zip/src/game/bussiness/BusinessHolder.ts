import * as PIXI from "pixi.js"
import TimeBar from './TimeBar';
import { AssetsPack } from "../../config";
import DisplayObject from '../../core/GameDisplayObject';
import BuyUpgradeButton from './BuyUpgradeButton';

class BusinessHolder extends DisplayObject {
    public bar: TimeBar;
    private businessConfig:any;

    constructor(businessConfig: any) {
        super(PIXI.utils.TextureCache[AssetsPack.Background.BusinessHolder]);
        this.businessConfig = this.businessConfig;
        this.setup();        
    }

    setup() {
        this.bar = new TimeBar(0);
        this.bar.x = 83;
        this.bar.y = 31;
        this.addChild(this.bar);

        const upgradeButton = new BuyUpgradeButton();
        upgradeButton.x = 80;
        upgradeButton.y = 75;
        this.addChild(upgradeButton);
    }

    onFrame() {
       this.bar.process += 0.01;
    }
}

export default BusinessHolder